create database student_database;

use student_database;

create table course (courseid int primary key ,course_name varchar(30),
fees decimal(10,2),course_type varchar(30),course_level varchar(50));
alter table course rename column courseid to course_id;

create table grade (grade_id int primary key, grade varchar(20),grade_date date,grade_status varchar(30));

create table student (student_id int primary key,grade_id int ,course_id int ,
firstname varchar(30),lastname varchar(30),gender varchar(20),address varchar(100),
mobile_no varchar(20),gmail varchar(100));
alter table student add foreign key(grade_id) references grade(grade_id);
alter table student add foreign key(course_id) references course(course_id);

create table enrollment(enrollment_no char(10) primary key,student_id int,
course_id int,enrollment_date date,status varchar(20),
foreign key(student_id) references student(student_id),foreign key(course_id) references course(course_id));

INSERT INTO course (course_id, course_name, fees, course_type, course_level) VALUES
(1, 'Mathematics', 500.00, 'Core', 'Undergraduate'),
(2, 'Physics', 550.00, 'Core', 'Undergraduate'),
(3, 'Chemistry', 600.00, 'Core', 'Undergraduate'),
(4, 'Biology', 650.00, 'Core', 'Undergraduate'),
(5, 'English Literature', 400.00, 'Elective', 'Undergraduate'),
(6, 'History', 450.00, 'Elective', 'Undergraduate'),
(7, 'Computer Science', 700.00, 'Core', 'Undergraduate'),
(8, 'Philosophy', 300.00, 'Elective', 'Undergraduate'),
(9, 'Art', 350.00, 'Elective', 'Undergraduate'),
(10, 'Economics', 500.00, 'Core', 'Undergraduate'),
(11, 'Statistics', 550.00, 'Core', 'Undergraduate'),
(12, 'Music', 300.00, 'Elective', 'Undergraduate'),
(13, 'Business Management', 800.00, 'Core', 'Postgraduate'),
(14, 'Engineering', 900.00, 'Core', 'Postgraduate'),
(15, 'Data Science', 950.00, 'Core', 'Postgraduate'),
(16, 'Graphic Design', 400.00, 'Elective', 'Postgraduate'),
(17, 'Cyber Security', 700.00, 'Core', 'Postgraduate'),
(18, 'Environmental Science', 650.00, 'Elective', 'Undergraduate'),
(19, 'Public Speaking', 250.00, 'Elective', 'Undergraduate'),
(20, 'Web Development', 500.00, 'Core', 'Postgraduate');

INSERT INTO grade (grade_id, grade, grade_date, grade_status) VALUES
(1, 'A', '2023-01-15', 'Completed'),
(2, 'B', '2023-02-10', 'Completed'),
(3, 'C', '2023-03-12', 'Completed'),
(4, 'D', '2023-04-20', 'In Progress'),
(5, 'A', '2023-05-15', 'Completed'),
(6, 'B', '2023-06-10', 'Completed'),
(7, 'A', '2023-07-12', 'In Progress'),
(8, 'C', '2023-08-15', 'Completed'),
(9, 'B', '2023-09-20', 'Completed'),
(10, 'D', '2023-10-05', 'In Progress'),
(11, 'C', '2023-11-15', 'Completed'),
(12, 'A', '2023-12-20', 'Completed'),
(13, 'B', '2024-01-25', 'Completed'),
(14, 'C', '2024-02-15', 'In Progress'),
(15, 'A', '2024-03-10', 'Completed'),
(16, 'B', '2024-04-05', 'Completed'),
(17, 'D', '2024-05-15', 'In Progress'),
(18, 'C', '2024-06-20', 'Completed'),
(19, 'B', '2024-07-15', 'Completed'),
(20, 'A', '2024-08-10', 'Completed');

INSERT INTO student (student_id, grade_id, course_id, firstname, lastname, gender, address, mobile_no, gmail) VALUES
(1, 1, 1, 'Alice', 'Johnson', 'Female', '123 Maple St', '123-456-7890', 'alice.johnson@gmail.com'),
(2, 2, 2, 'Bob', 'Smith', 'Male', '456 Oak St', '234-567-8901', 'bob.smith@gmail.com'),
(3, 3, 3, 'Charlie', 'Brown', 'Male', '789 Pine St', '345-678-9012', 'charlie.brown@gmail.com'),
(4, 4, 4, 'David', 'Wilson', 'Male', '135 Elm St', '456-789-0123', 'david.wilson@gmail.com'),
(5, 5, 5, 'Eva', 'Green', 'Female', '246 Cedar St', '567-890-1234', 'eva.green@gmail.com'),
(6, 6, 6, 'Frank', 'Miller', 'Male', '357 Birch St', '678-901-2345', 'frank.miller@gmail.com'),
(7, 7, 7, 'Grace', 'Davis', 'Female', '468 Walnut St', '789-012-3456', 'grace.davis@gmail.com'),
(8, 8, 8, 'Henry', 'Lopez', 'Male', '579 Spruce St', '890-123-4567', 'henry.lopez@gmail.com'),
(9, 9, 9, 'Isabella', 'Martinez', 'Female', '680 Ash St', '901-234-5678', 'isabella.martinez@gmail.com'),
(10, 10, 10, 'Jack', 'Hernandez', 'Male', '791 Cherry St', '012-345-6789', 'jack.hernandez@gmail.com'),
(11, 11, 11, 'Kathy', 'Garcia', 'Female', '902 Maple St', '123-456-7891', 'kathy.garcia@gmail.com'),
(12, 12, 12, 'Leo', 'Rodriguez', 'Male', '213 Oak St', '234-567-8902', 'leo.rodriguez@gmail.com'),
(13, 13, 13, 'Mia', 'Martinez', 'Female', '324 Pine St', '345-678-9013', 'mia.martinez@gmail.com'),
(14, 14, 14, 'Noah', 'Lopez', 'Male', '435 Elm St', '456-789-0124', 'noah.lopez@gmail.com'),
(15, 15, 15, 'Olivia', 'Williams', 'Female', '546 Cedar St', '567-890-1235', 'olivia.williams@gmail.com'),
(16, 16, 16, 'Paul', 'Jones', 'Male', '657 Birch St', '678-901-2346', 'paul.jones@gmail.com'),
(17, 17, 17, 'Quinn', 'Garcia', 'Female', '768 Walnut St', '789-012-3457', 'quinn.garcia@gmail.com'),
(18, 18, 18, 'Ryan', 'Davis', 'Male', '879 Spruce St', '890-123-4568', 'ryan.davis@gmail.com'),
(19, 19, 19, 'Sophia', 'Wilson', 'Female', '980 Ash St', '901-234-5679', 'sophia.wilson@gmail.com'),
(20, 20, 20, 'Tom', 'Hernandez', 'Male', '111 Cherry St', '012-345-6780', 'tom.hernandez@gmail.com');

INSERT INTO enrollment (enrollment_no, student_id, course_id, enrollment_date, status) VALUES
('ENR001', 1, 1, '2023-09-01', 'Active'),
('ENR002', 2, 2, '2023-09-02', 'Active'),
('ENR003', 3, 3, '2023-09-03', 'Active'),
('ENR004', 4, 4, '2023-09-04', 'Active'),
('ENR005', 5, 5, '2023-09-05', 'Active'),
('ENR006', 6, 6, '2023-09-06', 'Inactive'),
('ENR007', 7, 7, '2023-09-07', 'Active'),
('ENR008', 8, 8, '2023-09-08', 'Inactive'),
('ENR009', 9, 9, '2023-09-09', 'Active'),
('ENR010', 10, 10, '2023-09-10', 'Active'),
('ENR011', 11, 11, '2023-09-11', 'Active'),
('ENR012', 12, 12, '2023-09-12', 'Active'),
('ENR013', 13, 13, '2023-09-13', 'Inactive'),
('ENR014', 14, 14, '2023-09-14', 'Active'),
('ENR015', 15, 15, '2023-09-15', 'Active'),
('ENR016', 16, 16, '2023-09-16','Inactive');

#total revenue generated
select course_type,sum(fees) from course group by 1;

#total revenue
select sum(fees) from course;

#course with highest enrollment number
select course_type,count(enrollment_no) from course c inner join 
enrollment e on c.course_id=e.course_id group by 1;

#number of females in each course type
select course_type,count(gender) from student s inner join 
course c on c.course_id=s.course_id where gender="female" group by 1 ;

#courses under undergraduate and postgraduate
select course_level , group_concat(distinct course_name) from course group by 1;

#students with A grade
select concat(firstname," ",lastname) as name ,grade,student_id from 
student s inner join grade g on s.grade_id=g.grade_id where grade="a";

#pass fail ratio of the courses
with cte1 as (select course_type , count(grade) as passgrade from course c 
inner join student s on c.course_id=s.course_id inner join grade g on g.grade_id=s.grade_id 
where grade="A" or grade="B" or grade="C" group by 1), cte2 as 
(select course_type , count(grade) as failgrade from course c inner join 
student s on c.course_id=s.course_id inner join grade g on g.grade_id=s.grade_id 
where grade="D" group by 1) select cte1.course_type , concat(passgrade,":",failgrade) from cte1 inner join cte2;

#number of inactive courses
select course_type,count(status) from course c inner join 
enrollment e on c.course_id=e.course_id where status="inactive" group by 1;

#number of graded and inprogress students
select grade_status,count(*) from grade group by 1;

#how long is the time period between admission and result for various courses
select course_name,abs(month(enrollment_date)-month(grade_date)) from course c inner join 
student s on c.course_id=s.course_id inner join enrollment e on c.course_id=e.course_id 
inner join grade g on g.grade_id=s.grade_id; 


