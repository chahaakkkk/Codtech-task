create database hotel_booking;
use hotel_booking;
create table rooms (roomid int primary key,room_no int ,beds int,class char,rent decimal);
alter table rooms modify class varchar(40);
alter table rooms modify rent decimal(10,2);
create table customer (customerid int primary key,customername varchar(50) not null,members int default 2,roomid int ,contact_no varchar(20),photoidproof varchar(20),
photoidno varchar(30) unique,foreign key(roomid) references rooms(roomid));
create table payment(paymentid int primary key,customerid int,paymentmode varchar(20),amount decimal (10,2),foreign key(customerid) references customer(customerid));
create table reservations (reservationid int primary key ,reservationmode varchar(20),customerid int,paymentid int,foreign key(customerid) references customer(customerid),
foreign key(paymentid) references payment(paymentid));
alter table reservations add column resvdate date;
set sql_safe_updates=0;
#inserting valuse
insert into rooms values(1234501,001,1,"first class",6500),(1234502,002,2,"first class",8000),(1234503,003,4,"first class",12000),(1234504,004,3,"second class",5000),
(1234505,005,3,"second class",5000),(1234506,006,1,"second class",3000),(1234507,007,2,"second class",4000),(1234508,008,4,"second class",6000),(1234509,009,1,"third class",1500),
(1234510,010,2,"third class",2500);
insert into rooms values(1234511,011,3,"first class","10000"),(1234512,012,3,"third class",2000);

insert into customer values(5432101,"Anish",2,1234501,"6589423710","aadhaar card","543265486215"),(5432102,"Kiran",3,1234502,"6589423158","aadhaar card","862465486215"),
(5432103,"Bipin",6,1234503,"9989423710","voter id card","2654862151"),(5432104,"Chandra",5,1234504,"7894523710","aadhaar card","784265486215"),
(5432105,"Nikhil",6,1234505,"9651223710","pan card","ASKEH5486G"),(5432106,"Indra",2,1234506,"9089423710","aadhaar card","849263486220"),
(5432107,"Jayesh",3,1234507,"8256237104","Driving licence","MP9874632 094732"),(5432108,"Yash",7,1234508,"8569563526","voter id card","2563148965"),
(5432109,"Sunil",3,1234509,"6523104951","pan card","ASDRG321O"),(5432110,"Pravin",4,1234510,"7568412301","aadhaar card","652103251014");

insert into customer values (5432110,"Pravin",4,1234510,"7568412301","aadhaar card","652103251014");
insert into payment values(1098701,5432101,"card",6600),(1098702,5432102,"upi",8500),(1098703,5432103,"card",12800),(1098704,5432104,"card",5900),(1098705,5432105,"upi",5600),
(1098706,5432106,"upi",3600),(1098707,5432107,"cash",4500),(1098708,5432108,"upi",6300),(1098709,5432109,"cash",1600),(1098710,5432110,"upi",2600);

insert into reservations values(864201,"online",5432101,1098701,"2024-09-19"),(864202,"online",5432102,1098702,"2024-09-10"),(864203,"online",5432103,1098703,"2024-09-09"),
(864204,"at counter",5432104,1098704,"2024-09-06"),(864205,"at counter",5432105,1098705,"2024-09-06"),(864206,"online",5432106,1098706,"2024-09-03"),
(864207,"online",5432107,1098707,"2024-09-01"),(864208,"at counter",5432108,1098708,"2024-08-25"),(864209,"online",5432109,1098709,"2024-08-20"),
(864210,"at counter",5432110,1098710,"2024-08-13");

select * from rooms;
select * from customer;
select * from payment;
select * from reservations;

#quries

#how many rooms of each class is available in each class 
select ifnull(class,"total rooms") class,count(*) "number of rooms" from rooms group by class with rollup;

#average rent of rooms by class
select class,round(avg(rent),2) "average rent" from rooms group by class;

#total number ofbeds in the hotel
select sum(beds) "total beds" from rooms;

#avg number of members per booking
select avg(members) as "average number of members" from customer ;

#what is the most common type of photoid proof used by customer
select photoidproof , count(*) from customer group by photoidproof;

#total revenue generated this month
select sum(amount) from payment p inner join reservations r on p.paymentid=r.paymentid where month(resvdate)=9;

#which customer booked which room
select ifnull(customername,"empty room") as rooms,room_no from customer c right join rooms r on c.roomid=r.roomid ;

#number of empty rooms
select count(room_no) as "no empty room" from rooms r left join customer c on r.roomid=c.roomid where customerid is null;

#which customer uses which payment mode 
select paymentmode,group_concat(customername) from payment p inner join customer c on p.customerid=c.customerid group by paymentmode;

#updaing the rent of the room
update rooms set rent=9000 where roomid=1234511;

#rent payed by a customer is grater than a specified amount
select customername from customer c inner join rooms r on c.roomid=r.roomid where rent>7000; 

#updating customer room
update customer set roomid=1234511 where customerid=5432104;

#revenue generated over a specified period of time
select sum(amount) from payment p inner join reservations r on p.paymentid=r.paymentid where resvdate between "2024-08-15" and "2024-09-15";

#number of booking in offline and online mode
select reservationmode, count(*) from reservations group by reservationmode;

#taxes and amount of other facilites apart from rent
select customername, (amount-rent) from customer c inner join rooms r on r.roomid=c.roomid inner join payment p on c.customerid=p.customerid;

#revenue generated from offline and online modes
select reservationmode,round(avg(amount),2)from payment p inner join reservations r on p.paymentid=r.paymentid group by 1;

#customer who has sent the hight amount of money
select customername,amount from customer c inner join payment p on c.customerid=p.customerid order by amount desc limit 0,1;

#distributing customers according to number of members
select case when members>=5 then "large group" when members>2 then "small group" else "very small group" end as members ,count(*) from customer group by 1;

#print the names of the customers who have vowles in thier name
select customername from customer where customername like "%a%" or "%e%" or "%i%" or "%o%" or "%u%";

select * from customer;